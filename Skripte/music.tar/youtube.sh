#!/bin/bash

echo "link of the clip: "
read link
echo "link je $link"
echo "keywords: "
read keywords
keywords=$(echo $keywords | sed 's/ /,/g')
echo "keys je $keywords:"

title=$(youtube-dl --get-title $link)
description=$(youtube-dl --get-description $link)
youtube-dl -o clip $link

while read line
do
username=${line%:*}
password=${line#*:}
youtube-upload --email=$username --password=$password \
--description="http://www.impressagirl.info download FREE eBook Direct game! \
learn how to approach and attract girls! || $description sexy hot girl dance kiss" --title="$title" --keywords="$keywords" \
--category=Entertainment clip;
sleep 7
done < acc.txt
